<?php
/**
 * Created by PhpStorm.
 * User: Aui
 * Date: 8/7/2559
 * Time: 12:14
 */

header('location: login.php');