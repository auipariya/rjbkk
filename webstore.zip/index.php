<?php
header('location: buyticket');
?>

<!-- <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bangkok | Rockin' Jump</title>
    <style>
    html, body {
        height: 100%;
        margin: 0;
        background-color: #008d4c;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
        color: #ffffff;
    }
    
    img:first-child {
        width: 256px;
    }

    img:last-child {
        width: 256px;
        margin-top: 1rem;
    }
    </style>
</head>
<body>
    <img src="images/under-construction-640.png">
    <img src="images/rj-logo.png">
</body>
</html> -->