<?php
$activeMenu = 'viewcart';

include '../app/resources/app.header.php';

include 'list.php';

include '../app/resources/app.footer.php';