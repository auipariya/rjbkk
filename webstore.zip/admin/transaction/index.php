<?php
$activeMenu = 'adminTransaction';
$adminPageTitle = 'TRANSACTION';
?>

<?php include '../../app/resources/admin.header.php'; ?>
<div class="admin">
    <?php include 'list.php'; ?>
</div>
<?php include '../../app/resources/admin.footer.php'; ?>