<?php
$activeMenu = 'adminRemaining';
$adminPageTitle = 'REMAINING';
?>

<?php include '../../app/resources/admin.header.php'; ?>
<div>
    <?php include 'list.php'; ?>
</div>
<?php include '../../app/resources/admin.footer.php'; ?>