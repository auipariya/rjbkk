<?php

header('location: jumpclass');